export enum CategoryType {
  INCOME = 'INCOME',
  EXPENSE = 'EXPENSE',
}